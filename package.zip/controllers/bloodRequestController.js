const mongoose = require("mongoose");
const userModel = require("../models/userModel");
const bloodRequestModel = require("../models/bloodRequestModel");
// CREATE INVENTORY
const createReqInventoryController = async (req, res) => {

    const {user_id,role } = req.body;

  
        try {
        const user = await userModel.findOne({ _id:user_id });
        if (!user) {
            throw new Error("User Not Found");
        }
        if (user.role !== role) {
            throw new Error("Not a donar account");
        }
        const bloodRequest = new bloodRequestModel(req.body);
        await bloodRequest.save();
        res.status(200).json({
            status: "success",
            data: bloodRequest,
        });
    } catch (error) {
        res.status(400).json({
            status: "fail",
            message: error.message,
        });
    }
   
    

    //validation
};
// GET INVENTORY
const getReqInventoryController = async (req, res) => {

    try {
        const bloodRequest = await bloodRequestModel.find();
        res.status(200).json({
            status: "success",
            data: bloodRequest,
        });
    } catch (error) {
        res.status(400).json({
            status: "fail",
            message: error.message,
        });
    }

}
// GET INVENTORY
const editReqInventoryController = async (req, res) => {
    
        try {
            const { _id } = req.params;
            const bloodRequest = await bloodRequestModel.findOne({ _id: _id });
            res.status(200).json({
                status: "success",
                data: bloodRequest,
            });
        } catch (error) {
            res.status(400).json({
                status: "fail",
                message: error.message,
            });
        }
    
    }

    const deleteReqInventoryController = async (req, res) => {
        
            try {
                const { _id } = req.params;
                const bloodRequest = await bloodRequestModel.findOneAndDelete({ _id: _id });
                res.status(200).json({
                    status: "success",
                    data: bloodRequest,
                });
            } catch (error) {
                res.status(400).json({
                    status: "fail",
                    message: error.message,
                });
            }
        
        }
module.exports = {
    createReqInventoryController,
    getReqInventoryController,
    editReqInventoryController,
    deleteReqInventoryController
};
